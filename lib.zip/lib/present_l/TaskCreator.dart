import 'package:flutter/material.dart';

import '../data_l/models/dbtask.dart'; // Подставьте путь к модели Task

class TaskCreatorWidget extends StatelessWidget {
  final DateTime? seldate;

  const TaskCreatorWidget({super.key, required this.seldate});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        _showTaskCreationDialog(context);
      },
      child: Text('Добавить задачу'),
    );
  }

  void _showTaskCreationDialog(BuildContext context) {
    TextEditingController taskController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Создать задачу'),
          content: TextField(
            controller: taskController,
            decoration: InputDecoration(hintText: 'Объём работы'),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Отмена'),
            ),
            ElevatedButton(
              onPressed: () {
                String taskDescription = taskController.text;
                if (taskDescription.isNotEmpty) {
                  Task newTask = Task(
                    v: int.parse(taskDescription),
                    date_task: seldate!.toIso8601String(),
                    exec: 0, id_fieldwork: 1, // Здесь нужно установить выбранную дату
                  );
                  insertTask(newTask);
                  // Здесь можно добавить созданную задачу в базу данных
                  // addToDatabase(newTask);
                  Navigator.of(context).pop();
                } else {
                  // Показать сообщение об ошибке, если описание пустое
                }
              },
              child: Text('Создать'),
            ),
          ],
        );
      },
    );
  }
}