import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fproject/data_l/models/dbtypework.dart';
import '../data_l/models/dbfiedlwork.dart';
import '../data_l/models/dbfield.dart';
import 'dart:convert';

import '../main.dart';
import 'TaskCalendar.dart';


class MenuFieldWork extends StatefulWidget {
  final int id_field;
  final String description;
  final String city;


  const MenuFieldWork({Key? key, required this.id_field, required this.description, required this.city}) : super(key: key);

  @override
  State<MenuFieldWork> createState() => MenuFieldWork_Page1State();
}


class MenuFieldWork_Page1State extends State<MenuFieldWork> {
  String? field_name;

  @override
  void initState() {
    getField(widget.id_field).then(
            (value) {
              field_name=value.description;
              setState(() {

              });

            }
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ПОЛЕ:$field_name /ПЛАНЫ'),

        leading: IconButton(
          icon: const Icon(Icons.nature_people_rounded),
          onPressed: () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomePage(page: 'page2'))
            );
          },
        ),

        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context)
              => HomePage(page: result)));},

            itemBuilder: (BuildContext context) => [
              const PopupMenuItem(
                  value: 'home',
                  child: Row(
                    children: [
                      Text('Домой'),
                      Icon(Icons.home),
                    ],
                  )
              ),
              const PopupMenuItem(
                value: 'page1',
                child: Text('Новое'),
              ),
              const PopupMenuItem(
                value: 'page2',
                child: Text('В работе'),
              ),
              const PopupMenuItem(
                value: 'page3',
                child: Text('Аналитика'),
              ),
            ],
          ),
        ],
      ),


      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Center(
              child: Text('Создание или просмотр планов работ'),
            ),


            ElevatedButton(
              child: Text('Планы обработки поля: $field_name'),
              onPressed: () =>
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => ListFieldWorks(
                        widget.id_field,
                        widget.description,
                        widget.city
                    )),
                  ),
            ),

            ElevatedButton(
              child: const Text('+ Создать новый план работ +'),
              onPressed: () =>
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => CreateFieldWork(
                        widget.id_field,
                        widget.description,
                      widget.city
                    )),
                  ),
            ),

          ],
        ),
      ),
    );
  }
}








class CreateFieldWork extends StatefulWidget {
  final int id_field;
  final String description;
  final String city;

  const CreateFieldWork(this.id_field, this.description, this.city, {Key? key}) : super(key: key);

  @override
  State<CreateFieldWork> createState() => CreateFieldWorkState(
    id_field, description, city
  );
}


class CreateFieldWorkState extends State<CreateFieldWork> {
  final int id_field;
  final String description;
  final String city;
  var dropdownvalue;
  List<String> items = [];
  var typeworks;

  CreateFieldWorkState(this.id_field, this.description, this.city);



  TextEditingController workloadController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _getItems();
  }

  _getItems() async {
    List<TypeWork> typeworks = await selectTypeWorksAll();
    setState(() {
      this.typeworks = typeworks;
      items = typeworks.map((e) => e.type_work).toList();
      if (items.isNotEmpty) {
        dropdownvalue = items[0];
      }
    }
    );
  }

  addField(var workload) async {
    int id_typework = typeworks.firstWhere((object) => object.type_work == dropdownvalue).id;
    insertFieldWork(FieldWork(workload: workload, id_field: id_field, id_typework: id_typework));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: const Text('ПОЛЕ:../ПЛАНЫ/СОЗДАНИЕ'),

        leading: IconButton(
          icon: const Icon(Icons.pending_actions),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    MenuFieldWork(

                      description: description,
                      city: city,
                      id_field: id_field,
                    ),
              ),
            );
          },
        ),

        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context)
              => HomePage(page: result)));},

            itemBuilder: (BuildContext context) => [
              const PopupMenuItem(
                  value: 'home',
                  child: Row(
                    children: [
                      Text('Домой'),
                      Icon(Icons.home),
                    ],
                  )
              ),
              const PopupMenuItem(
                value: 'page1',
                child: Text('Новое'),
              ),
              const PopupMenuItem(
                value: 'page2',
                child: Text('В работе'),
              ),
              const PopupMenuItem(
                value: 'page3',
                child: Text('Аналитика'),
              ),
            ],
          ),
        ],
      ),



      body: Column(
        children: [
          // форма для создания новой записи
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Text('Обрабатываемое поле: $description'),
                Text('Область: $city'),

                TextField(
                  controller: workloadController,
                  decoration: const InputDecoration(
                    labelText: 'Сколько обрабатывать? (в ГА)',
                  ),
                ),

                DropdownButton(
                  value: dropdownvalue,
                  icon: const Icon(Icons.keyboard_arrow_down),
                  items: items.map((var items) {
                    return DropdownMenuItem(
                      value: items,
                      child: Text(items.toString()),
                    );
                  }).toList(),
                  onChanged: (var newValue) {
                    setState(() {
                      dropdownvalue = newValue!;
                    });
                  },
                ),

                ElevatedButton(
                  onPressed: () {
                    // вызываем метод для добавления новой записи
                    addField(int.parse(workloadController.text.toString()));
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) =>
                            ListFieldWorks(
                                widget.id_field,
                                widget.description,
                                widget.city
                            ))
                    );
                  }
                  ,
                  child: const Text('Создать'),
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }
}


class ListFieldWorks extends StatefulWidget {
  final int id_field;
  final String description;
  final String city;

  const ListFieldWorks(this.id_field, this.description, this.city, {Key? key}) : super(key: key);

  @override
  State<ListFieldWorks> createState() => ListFieldWorkssState(
      id_field, description, city
  );
}


class ListFieldWorkssState extends State<ListFieldWorks> {
  final int id_field;
  final String description;
  final String city;

  ListFieldWorkssState(this.id_field, this.description, this.city);



  _deleteFieldWork(int id) {
    deleteFieldWork(id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ПОЛЕ:../ПЛАНЫ/СОЗАННЫЕ'),

        leading: IconButton(
          icon: const Icon(Icons.pending_actions),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    MenuFieldWork(

                      description: description,
                      city: city,
                      id_field: id_field,
                    ),
              ),
            );
          },
        ),

        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context)
              => HomePage(page: result)));},

            itemBuilder: (BuildContext context) => [
              const PopupMenuItem(
                  value: 'home',
                  child: Row(
                    children: [
                      Text('Домой'),
                      Icon(Icons.home),
                    ],
                  )
              ),
              const PopupMenuItem(
                value: 'page1',
                child: Text('Новое'),
              ),
              const PopupMenuItem(
                value: 'page2',
                child: Text('В работе'),
              ),
              const PopupMenuItem(
                value: 'page3',
                child: Text('Аналитика'),
              ),
            ],
          ),
        ],
      ),


      body: FutureBuilder(
        future: selectFieldWorksAll(id_field),
        builder: (BuildContext context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data?.length,
              itemBuilder: (BuildContext context, int index) {
                return Material(
                  elevation: 3.0,
                  shadowColor: Colors.blueGrey,
                  child: ListTile(
                    title: SpecialText(
                      id_typework: snapshot.data![index].id_typework, child: null,),
                    subtitle: SpecialTextField(
                      id_field: snapshot.data![index].id_field, child: null,
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () {
                        _deleteFieldWork(snapshot.data![index].id);
                        setState(() {});
                      },
                    ),
                    onTap: () =>
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => CalendarWidget_(fieldwork_id: snapshot.data![index].id,
                            field: snapshot.data![index].id_field, )),
                        ),
                  ),
                );
              },

            );
          }
          else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        }
        ,
      ),
    );
  }
}


class SpecialText extends StatefulWidget {
  final Widget? child;
  final int id_typework;
  const SpecialText({Key? key, required this.id_typework, this.child, }) : super(key: key);

  @override
  State<SpecialText> createState() => SpecialTextState();
}


class SpecialTextState extends State<SpecialText> {
  TypeWork? typeWork;

  @override
  void initState() {
    super.initState();
    initText();
  }

  initText() async {
    await getTypeWork(widget.id_typework).then((value) => typeWork = value);
    setState(() {});
  }

  @override
  build(BuildContext context) {
    return Text('Тип работы: ${typeWork?.type_work}, \n ${typeWork?.cultures}');
  }
}


class SpecialTextField extends StatefulWidget {
  final Widget? child;
  final int id_field;
  const SpecialTextField({Key? key, required this.id_field, this.child, }) : super(key: key);

  @override
  State<SpecialTextField> createState() => SpecialTextFieldState();
}


class SpecialTextFieldState extends State<SpecialTextField> {
  Field? field;

  @override
  void initState() {
    super.initState();
    initText();
  }

  initText() async {
    await getField(widget.id_field).then((value) => field = value);
    setState(() {});
  }

  @override
  build(BuildContext context) {
    return Text('Поле: ${field?.description}, в ${field?.city}');
  }
}