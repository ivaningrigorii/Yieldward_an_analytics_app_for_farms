import 'package:flutter/material.dart';
import 'package:fproject/data_l/models/dbfield.dart';
import 'package:fproject/data_l/models/dbwhether.dart';
import 'package:table_calendar/table_calendar.dart';

import '../buisnes_I/wheather.dart';
import '../data_l/models/dbtask.dart';
import '../main.dart';
import 'FieldWorkPages.dart';
import 'TaskCreator.dart';


class CalendarWidget_ extends StatefulWidget{
  final int fieldwork_id;
  final int field;

  const CalendarWidget_({super.key, required this.fieldwork_id, required this.field});

  @override
  State<CalendarWidget_> createState() => _TableEventsExampleState();

}


class _TableEventsExampleState extends State<CalendarWidget_> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  RangeSelectionMode _rangeSelectionMode = RangeSelectionMode
      .toggledOff;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  DateTime? _rangeStart;
  DateTime? _rangeEnd;
  Whether? whether;
  Field? field_object;

  @override
  void initState() {
    super.initState();

    _selectedDay = _focusedDay;
    getField(widget.field).then(
            (value) {
          field_object=value;
          setState(() {});

            });
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget whetherAnalyz() {
    String text = 'Идеальные погодные условия.';
    ColorSwatch<int> color = Colors.green;

    // оценка температуры
    if (whether!.temperature < 18
          || whether!.temperature >= 35) {
      text = 'Неудачная темперература..';
      color = Colors.orangeAccent;
    }
    // оценка вероятности осадков
    if (whether!.rainProbability > 50) {
      text = 'Высока вероятность осадков!';
      color = Colors.redAccent;
    }

    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(16),
      color: color,
      child: Text(
        '$text \n${whether?.temperature.round()}°С, влажность: ${whether?.rainProbability.round()}'
      ),
    );
  }

  changeVals() {
    getField(widget.field).then((field) =>
        getWeatherForecast(field.city).then((value) {
          Map<String, dynamic>? listvals = {};
          listvals = (
              value.where((element) =>
              DateTime
                  .parse(element.values.toList()[0]).hour == 9 &&
                  DateTime.parse(element.values.toList()[0]).month == _selectedDay?.month &&
                  DateTime.parse(element.values.toList()[0]).day == _selectedDay?.day
              ).firstOrNull
          );

          if (listvals != null) {
            whether = Whether(
                dateTime_: listvals['dateTime'],
                temperature: listvals['temperature'],
                rainProbability: listvals['rainProbability']
            );
          } else {
              whether = null;
          }

            setState(() { });

        })
    );
  }


  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    if (!isSameDay(_selectedDay, selectedDay)) {
      setState(() {
        _selectedDay = selectedDay;
        _focusedDay = focusedDay;
        _rangeStart = null; // Important to clean those
        _rangeEnd = null;
        _rangeSelectionMode = RangeSelectionMode.toggledOff;
        changeVals();
      });
    }
  }

  void _onRangeSelected(DateTime? start, DateTime? end, DateTime focusedDay) {
    setState(() {
      _selectedDay = null;
      _focusedDay = focusedDay;
      _rangeStart = start;
      _rangeEnd = end;
      _rangeSelectionMode = RangeSelectionMode.toggledOn;
      changeVals();
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ПОЛЕ:../ПЛАН/ЗАДАЧИ'),

        leading: IconButton(
          icon: const Icon(Icons.pending_actions),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    ListFieldWorks(widget.field,field_object!.description,field_object!.city,
                    ),
              ),
            );
          },
        ),

        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context)
              => HomePage(page: result)));},

            itemBuilder: (BuildContext context) => [
              const PopupMenuItem(
                  value: 'home',
                  child: Row(
                    children: [
                      Text('Домой'),
                      Icon(Icons.home),
                    ],
                  )
              ),
              const PopupMenuItem(
                value: 'page1',
                child: Text('Новое'),
              ),
              const PopupMenuItem(
                value: 'page2',
                child: Text('В работе'),
              ),
              const PopupMenuItem(
                value: 'page3',
                child: Text('Аналитика'),
              ),
            ],
          ),
        ],
      ),


      body: Column(
        children: [
          TableCalendar(
            firstDay: DateTime(2023),
            lastDay: DateTime(2025),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            calendarFormat: _calendarFormat,
            rangeSelectionMode: _rangeSelectionMode,
            startingDayOfWeek: StartingDayOfWeek.monday,
            calendarStyle: const CalendarStyle(
              outsideDaysVisible: false,
            ),
            onDaySelected: _onDaySelected,
            onRangeSelected: _onRangeSelected,
            onFormatChanged: (format) {
              if (_calendarFormat != format) {
                setState(() {
                  _calendarFormat = format;
                });
              }
            },
            onPageChanged: (focusedDay) {
              _focusedDay = focusedDay;
            },
          ),
          const SizedBox(height: 8.0),

          ElevatedButton(
            onPressed: () {
              TextEditingController taskController = TextEditingController();

              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text('Создать задачу'),
                    content: TextField(
                      controller: taskController,
                      decoration: const InputDecoration(hintText: 'Объём работы, в Га:'),
                    ),
                    actions: <Widget>[
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: const Text('Отмена'),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          String taskDescription = taskController.text;
                          if (taskDescription.isNotEmpty) {
                            Task newTask = Task(
                              v: int.parse(taskDescription),
                              date_task: _selectedDay!.toIso8601String(),
                              exec: 0, id_fieldwork: widget.fieldwork_id, // Здесь нужно установить выбранную дату
                            );
                            insertTask(newTask);
                            setState(() {});
                            // Здесь можно добавить созданную задачу в базу данных
                            // addToDatabase(newTask);
                            Navigator.of(context).pop();
                          } else {
                            // Показать сообщение об ошибке, если описание пустое
                          }
                        },
                        child: const Text('Создать'),
                      ),
                    ],
                  );
                },
              );
            },
            child: const Text('Добавить задачу'),
          ),

          const SizedBox(height: 8.0),

          whether == null?
          const Card(
            elevation: 4,
            margin: EdgeInsets.all(16),
            color: Colors.white30,
            child: Text('Данных о погоде нет'),
          ):
          whetherAnalyz(),

          const SizedBox(height: 8.0),

          FutureBuilder(
            future: selectTasksSome(widget.fieldwork_id, _selectedDay!),
            builder: (BuildContext context, snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: snapshot.data?.length,
                  itemBuilder: (BuildContext context, int index) {
                    return ListTile(
                      title: Text('Нужно обработать ${snapshot.data![index].v} Га'),
                      subtitle: const Text('Задача'),
                      trailing: Wrap(
                        spacing: 12, // space between two icons
                        children: <Widget>[
                          IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () {
                              deleteTask(snapshot.data![index].id);
                              setState(() {});
                            },
                          ),
                          snapshot.data![index].exec==0 ?
                          IconButton(
                            icon: const Icon(Icons.panorama_fish_eye),
                            onPressed: () {
                              chageTaskExeck(snapshot.data![index].id, 1);
                              setState(() {});
                            },
                          ) :
                          IconButton(
                            icon: const Icon(Icons.check),
                            onPressed: () {
                              chageTaskExeck(snapshot.data![index].id, 0);
                              setState(() {});
                            },
                          )
                        ],
                      ),

                      // onTap: () =>
                      //     Navigator.push(
                      //       context,
                      //       MaterialPageRoute(builder: (context) => CalendarWidget_(fieldwork_id: snapshot.data![index].id,)),
                      //     ),
                    );
                  },

                );
              }
              else {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
            }
            ,
          ),

        ],
      ),
    );
  }}