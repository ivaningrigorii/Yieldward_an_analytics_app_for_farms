import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fproject/main.dart';
import '../data_l/models/dbfield.dart';
import 'dart:convert';

import '../main.dart';
import '../main.dart';
import 'FieldPages.dart';
import 'FieldWorkPages.dart';

class Page1 extends StatefulWidget {
  const Page1({Key? key}) : super(key: key);

  @override
  State<Page1> createState() => _Page1State();
}


class _Page1State extends State<Page1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Новый сезон работ'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Center(
              child: Text('Создайте новое поле.\nИли выберете из старых.'),
            ),

            ElevatedButton(
              child: const Text('новое поле'),
              onPressed: () =>
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => CreateField()),
                  ),
            ),
            ElevatedButton(
              child: const Text('выбор поля'),
              onPressed: () =>
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const ListFields()),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}




class CreateField extends StatefulWidget {
  const CreateField({Key? key}) : super(key: key);

  @override
  State<CreateField> createState() => CreateField_Page1State();
}


class CreateField_Page1State extends State<CreateField> {
  TextEditingController descriptionController = TextEditingController();
  TextEditingController cityController = TextEditingController();

  // метод для добавления новой записи в таблицу
  void addField(String description, String city) {
    insertField(Field(description: description, city: city));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ДОБАВЛЕНИЕ ПОЛЯ'),

        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomePage(page: 'home'))
            );
          },
        ),

        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context)
                    => HomePage(page: result)));},

            itemBuilder: (BuildContext context) => [
              const PopupMenuItem(
                value: 'home',
                child: Row(
                  children: [
                  Text('Домой'),
                  Icon(Icons.home),
                ],
              )
              ),
              const PopupMenuItem(
                value: 'page1',
                child: Text('Новое'),
              ),
              const PopupMenuItem(
                value: 'page2',
                child: Text('В работе'),
              ),
              const PopupMenuItem(
                value: 'page3',
                child: Text('Аналитика'),
              ),
            ],
          ),
        ],
      ),


      body: Column(
        children: [
          // форма для создания новой записи
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Однозначное описание поля',
                  ),
                ),
                TextField(
                  controller: cityController,
                  decoration: const InputDecoration(
                    labelText: 'Область (город латинскими буквами)',
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    // вызываем метод для добавления новой записи
                    addField(descriptionController.text, cityController.text);

                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => const ListFields())
                    );
                  }

                  ,
                  child: const Text('Создать поле'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}





class ListFields extends StatefulWidget {
  const ListFields({Key? key}) : super(key: key);

  @override
  State<ListFields> createState() => ListFieldsState();
}


class ListFieldsState extends State<ListFields> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ПОЛЯ'),

        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomePage(page: 'home'))
            );
          },
        ),

        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context)
              => HomePage(page: result)));},

            itemBuilder: (BuildContext context) => [
              const PopupMenuItem(
                  value: 'home',
                  child: Row(
                    children: [
                      Text('Домой'),
                      Icon(Icons.home),
                    ],
                  )
              ),
              const PopupMenuItem(
                value: 'page1',
                child: Text('Новое'),
              ),
              const PopupMenuItem(
                value: 'page2',
                child: Text('В работе'),
              ),
              const PopupMenuItem(
                value: 'page3',
                child: Text('Аналитика'),
              ),
            ],
          ),
        ],
      ),




      body: FutureBuilder(
        future: selectFieldsAll(),
        builder: (BuildContext context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data?.length,
              itemBuilder: (context, index) {
                return Material(
                    elevation: 3.0,
                    shadowColor: Colors.blueGrey,
                    child: ListTile(
                      title: Text(snapshot.data![index].description),
                      subtitle: Text(snapshot.data![index].city),
                      textColor: Colors.black,
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          deleteField(snapshot.data![index].id);
                          setState(() {

                          });
                        },
                      ),
                      onTap: () =>
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  MenuFieldWork(

                                    description: snapshot.data![index].description,
                                    city: snapshot.data![index].city,
                                    id_field: snapshot.data![index].id,
                                  ),
                            ),
                          )
                      ,
                    ),
                );


              }

              ,
            );
          } else if (snapshot.hasError) {
            return const Text('--');

          }
          else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        }
        ,
      ),
    );
  }
}
