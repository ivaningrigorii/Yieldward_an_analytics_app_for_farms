import '../database.dart';
// ignore: depend_on_referenced_packages
import 'package:sqflite/sqlite_api.dart';

class Field {
  int id;
  String description;
  String city;

  Field({
    this.id = 0,
    required this.description,
    required this.city
  });

  Map<String, dynamic> toMap() {
    return {'city': city, 'description': description};
  }

  @override
  String toString() {
    return 'Field{city: $city, description: $description}';
  }
}

Future<void> insertField(Field field) async {
  var provider = DBProvider();
  final db = await provider.database;
  print(field.toMap());
    db.insert(
      'field_', field.toMap()
    ).then((value) => print("Добавлена запись сid = $value"));
}

// A method that retrieves all the music rows from the dogs table.
Future<List<Field>> selectFieldsAll() async {
  // Get a reference to the database.
  var provider = DBProvider();
  final db = await provider.database;

  // Query the table for all The Dogs.
  final List<Map<String, dynamic>> maps = await db.query('field_');

  // Convert the List<Map<String, dynamic> into a List<Dog>.
  return List.generate(maps.length, (i) {
    return Field(
      id: maps[i]['id'],
      description: maps[i]['description'],
      city: maps[i]['city'],
    );
  });
}

// A method that retrieves all the music rows from the dogs table.
Future truncateFields() async {
  // Get a reference to the database.
  var provider = DBProvider();
  final db = await provider.database;

  db.delete('field_;');
}

// A method that retrieves all the music rows from the dogs table.
Future deleteField(int id) async {
  // Get a reference to the database.
  var provider = DBProvider();
  final db = await provider.database;
  db.execute("PRAGMA foreign_keys=ON");
  db.delete('field_', where: "id = ?", whereArgs: [id]);
}


Future<Field> getField(int id) async {
  var provider = DBProvider();
  final db = await provider.database;

  List<Map<String, dynamic>> maps = await db.query('field_', where: 'id = ?', whereArgs: [id]);

  var t = Field(
    id: maps[0]['id'],
    description: maps[0]['description'],
    city: maps[0]['city'],
  );

  return t;
}