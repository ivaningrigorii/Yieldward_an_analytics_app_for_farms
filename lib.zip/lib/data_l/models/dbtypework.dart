import '../database.dart';
// ignore: depend_on_referenced_packages
import 'package:sqflite/sqlite_api.dart';

class TypeWork {
  int id;
  String type_work;
  String cultures;

  TypeWork({
    this.id = 0,
    required this.type_work,
    required this.cultures
  });

  Map<String, dynamic> toMap() {
    return {'type_work': type_work, 'cultures': cultures};
  }

  @override
  String toString() {
    return 'Field{type_work: $type_work, cultures: $cultures}';
  }
}




// A method that retrieves all the music rows from the dogs table.
Future<List<TypeWork>> selectTypeWorksAll() async {
  // Get a reference to the database.
  var provider = DBProvider();
  final db = await provider.database;

  // Query the table for all The Dogs.
  final List<Map<String, dynamic>> maps = await db.query('typework');

  // Convert the List<Map<String, dynamic> into a List<Dog>.
  return List.generate(maps.length, (i) {
    return TypeWork(
      id: maps[i]['id'],
      type_work: maps[i]['type_work'],
      cultures: maps[i]['cultures']
    );
  });
}


Future<TypeWork> getTypeWork(int id) async {
  var provider = DBProvider();
  final db = await provider.database;

  List<Map<String, dynamic>> maps = await db.query('typework', where: 'id = ?', whereArgs: [id]);

  var t = TypeWork(
    id: maps[0]['id'],
    type_work: maps[0]['type_work'],
    cultures: maps[0]['cultures'],
  );

  return t;
}









