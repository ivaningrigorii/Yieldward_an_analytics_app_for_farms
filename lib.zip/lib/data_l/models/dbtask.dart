import 'dart:ffi';

import '../database.dart';
// ignore: depend_on_referenced_packages
import 'package:sqflite/sqlite_api.dart';



class Task {
  int id;
  int v;
  int exec;
  int id_fieldwork;
  String date_task;

  Task({
    this.id = 0,
    required this.v,
    required this.exec,
    required this.id_fieldwork,
    required this.date_task,
  });

  Map<String, dynamic> toMap() {
    return {'v': v, 'exec': exec, 'id_fieldwork': id_fieldwork, 'date_task':date_task};
  }

  @override
  String toString() {
    return 'Field{v: $v, exec: $exec}';
  }
}


Future<List<Task>> selectTasksSome(int fieldwork_id, DateTime selected_date) async {
  var provider = DBProvider();
  final db = await provider.database;

  final List<Map<String, dynamic>> maps = await db.query(
      'task', where: 'id_fieldwork = ? and date_task = ?',
      whereArgs: [fieldwork_id, selected_date.toIso8601String()]
  );

  return List.generate(maps.length, (i) {
    return Task(
        id: maps[i]['id'],
        v: maps[i]['v'],
        exec: maps[i]['exec'],
      id_fieldwork: maps[i]['id_fieldwork'],
      date_task: maps[i]['date_task'],
    );
  });
}

Future<List<Task>> selectTasksAlll() async {
  var provider = DBProvider();
  final db = await provider.database;

  final List<Map<String, dynamic>> maps = await db.query('task');

  print('вот тут вот');
  print(maps.toString());

  return List.generate(maps.length, (i) {
    return Task(
      id: maps[i]['id'],
      v: maps[i]['v'],
      exec: maps[i]['exec'],
      id_fieldwork: maps[i]['id_fieldwork'],
      date_task: maps[i]['date_task'],
    );
  });
}

Future<void> insertTask(Task task) async {
  var provider = DBProvider();
  final db = await provider.database;

  db.insert(
      'task', task.toMap()
  ).then((value) => print("Добавлена запись сid = $value"));
}

// A method that retrieves all the music rows from the dogs table.
Future deleteTask(int id) async {
  var provider = DBProvider();
  final db = await provider.database;

  db.execute("PRAGMA foreign_keys=ON");
  db.delete('task', where: "id = ?", whereArgs: [id]);
}

// A method that retrieves all the music rows from the dogs table.
Future chageTaskExeck(int id, int exec) async {
  var provider = DBProvider();
  final db = await provider.database;

  db.update('task', {'exec':exec}, where: "id = ?", whereArgs: [id]);
}
