import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';


import 'package:flutter/foundation.dart' show kIsWeb;

class DBProvider {
  static final DBProvider db = DBProvider();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDB();
    return _database!;
  }

  Database? getDB() {
    return _database;
  }

  initDB() async {
    String path;

    Directory documentsDirectory = await getApplicationSupportDirectory();
    path = join(documentsDirectory.path, "ProjectDB.db");


    return await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
          db.execute("PRAGMA foreign_keys=ON");
          db.execute("""
            CREATE TABLE field_ (
              id integer PRIMARY KEY AUTOINCREMENT,
              description text NOT NULL,
              city text NOT NULL
            );
          """);
          db.execute("""
          CREATE TABLE typework (
	          id integer PRIMARY KEY AUTOINCREMENT,
  	        type_work text,
  	        cultures text
          );
          """);
          db.execute("""
          insert into typework (id, type_work, cultures)
          VALUES 
	          (1, 'Уборка урожая', 'пшеница, ячмень'),
            (2, 'вспашка земель', ''),
            (3, 'обработка поля дискаторами', '');
          """);

          db.execute("""
            CREATE table fieldwork (
	            id integer PRIMARY KEY AUTOINCREMENT,
  	          workload integer,
  	          id_field integer,
  	          id_typework integer,
  
  	          foreign key (id_field) REFERENCES field_(id) ON DELETE CASCADE,
  	          FOREIGN KEY (id_typework) REFERENCES typework(id) ON DELETE CASCADE
  	
            );
          """);
          db.execute("""
            CREATE TABLE task (
              id integer PRIMARY KEY AUTOINCREMENT,
              v integer,
              exec integer,
              id_fieldwork integer,
              date_task string,
              
              FOREIGN KEY (id_fieldwork) REFERENCES fieldwork(id) ON DELETE CASCADE
            );
          """);
          db.execute("""
            CREATE TABLE whether (
              id integer PRIMARY KEY AUTOINCREMENT,
              dateTime_ string,
              temperature real,
              rainProbability real,
              id_fieldwork int,
              
              FOREIGN KEY (id_fieldwork) REFERENCES fieldwork(id) ON DELETE CASCADE
            );
          """);
          db.execute("PRAGMA foreign_keys=ON");
        });
  }
}