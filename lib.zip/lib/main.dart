import 'dart:io';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:fproject/data_l/models/dbfiedlwork.dart';
import 'package:fproject/data_l/models/dbfield.dart';
import 'package:fproject/data_l/models/dbtypework.dart';
import 'buisnes_I/wheather.dart';
import 'present_l/FieldPages.dart';

import 'dart:io';
import 'dart:async';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ПОМОЩНИК ФЕРМЕРУ',
      debugShowCheckedModeBanner:false,
      color: Colors.teal,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const HomePage(page: 'home'),
    );
  }
}

class HomePage extends StatefulWidget {
  final String page;

  const HomePage({super.key, required this.page});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  late int _currentIndex;
  var pages_ = [
    Home(),
    CreateField(),
    ListFields(),
    Page3()
  ];

  @override
  void initState() {
    _currentIndex = ['home', 'page1', 'page2', 'page3'].indexOf(widget.page);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        top: false,
        child: IndexedStack(
          index: _currentIndex,
          children: pages_,
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (int index) {
          setState(() {
            if (index==0) {
              pages_[0]= Home();
            }
            if (index==1) {
              pages_[1]= CreateField();
            }
            if (index==2) {
              pages_[2]= ListFields();
            }
            if (index==3) {
              pages_[3] = Page3();
            }
            _currentIndex = index;
          });
        },

        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'ГЛАВНАЯ',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.nature_people_outlined),
            label: 'НОВОЕ',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.nature_people_rounded),
            label: 'ПОЛЯ',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.auto_graph),
            label: 'СТАТИСТИКА'

          ),
        ],
      ),
    );
  }
}


class Page2 extends StatelessWidget {
  const Page2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Все сезоны работ'),
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Все сезоны работ'),

          ],
        ),
      ),
    );
  }}



class Home extends StatelessWidget {
  const Home({super.key});

  Future<File> _getLocalFile(String filename) async {
    String dir = (await getApplicationDocumentsDirectory()).path;
    File f = File('$dir/$filename');
    return f;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ПОМОЩНИК ФЕРМЕРУ'),
        backgroundColor: Colors.red,
      ),
      body: Stack(
          children: <Widget>[
            Container(
              alignment: Alignment.topCenter,
              child: Text('Фермерский помощник'),
            ),
            Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/tractor.jpg"),
                  fit: BoxFit.fitWidth,
                ),
              ),
            ),



          ],
        ),
     
    );
  }}



class Page3 extends StatefulWidget {
  const Page3({super.key});
  @override
  Page3_HomePageState createState() => Page3_HomePageState();
}

class Page3_HomePageState extends State<Page3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: const Text('СТАТИСТИКА'),

        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomePage(page: 'home'))
            );
          },
        ),

        actions: [
          PopupMenuButton<String>(
            onSelected: (String result) {
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context)
              => HomePage(page: result)));},

            itemBuilder: (BuildContext context) => [
              const PopupMenuItem(
                  value: 'home',
                  child: Row(
                    children: [
                      Text('Домой'),
                      Icon(Icons.home),
                    ],
                  )
              ),
              const PopupMenuItem(
                value: 'page1',
                child: Text('Новое'),
              ),
              const PopupMenuItem(
                value: 'page2',
                child: Text('В работе'),
              ),
              const PopupMenuItem(
                value: 'page3',
                child: Text('Аналитика'),
              ),
            ],
          ),
        ],
      ),

      body:  Column(
          children: <Widget>[
            const Text('Статистика по активным планам'),
            FutureBuilder(
              future: selectActivePlansStat(),
              builder: (BuildContext context, snapshot) {
                if (snapshot.data != null && snapshot.hasData) {
                  return Expanded(child:
                  ListView.builder(
                    shrinkWrap: true,
                    primary: false,
                    itemCount: snapshot.data?.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Column(
                        children: <Widget>[
                          if (snapshot.data != null)
                            FutureBuilder(
                        future: getFieldWork(snapshot.data![index].id_fieldwork),
                        builder: (BuildContext context, AsyncSnapshot<FieldWork> snapshot2) {
                          return
                            Row(
                              children: [
                                const Text('       План:'),
                                FutureBuilder(
                                  future: getTypeWork(snapshot2.data!.id_typework),
                                  builder: (BuildContext context, AsyncSnapshot<TypeWork> snapshot3) {
                                    return snapshot3.data!=null?
                                    Text(' ${snapshot3.data!.type_work.toString()}')
                                        :
                                    const Text('');
                                  },
                                ),
                                FutureBuilder(
                                  future: getField(snapshot2.data!.id_field),
                                  builder: (BuildContext context, AsyncSnapshot<Field> snapshot4) {
                                    return snapshot4.data != null?
                                    Text(', на поле ${snapshot4.data!.description}'):
                                    const Text('');
                                  },
                                ),
                              ],
                            );
                        },

                      ),


                          const Padding(padding: EdgeInsets.all(60)),

                          if (snapshot.data != null)
                          SizedBox(
                            height: 20,
                            child:
                            PieChart(PieChartData(
                                centerSpaceRadius: 10,
                                borderData: FlBorderData(show: true),
                                sections: [
                                  PieChartSectionData(
                                      value: snapshot.data![index].sum_t.toDouble(),
                                      color: Colors.green, radius: 100,
                                      title: 'обработано'),

                                  PieChartSectionData(

                                      value: snapshot.data![index].sum_f.toDouble(),
                                      color: Colors.yellow, radius: 100,
                                      title: 'в планах'),


                                  PieChartSectionData(value: (
                                      snapshot.data![index].workload.toDouble() -
                                          snapshot.data![index].sum_f.toDouble() -
                                          snapshot.data![index].sum_t.toDouble()

                                  ) , color: Colors.grey, radius: 100,
                                      title: 'осталось ${
                                          snapshot.data![index].workload.toDouble() -
                                              snapshot.data![index].sum_f.toDouble() -
                                              snapshot.data![index].sum_t.toDouble()
                                      }'),
                                ]),),

                          ),
                          const Padding(padding: EdgeInsets.all(70)),
                        ],
                      );
                    },
                  )
                  );
                }
                else {
                  return Container();
                }
              }
              ,
            ),
          ],
        ),
    );
  }}